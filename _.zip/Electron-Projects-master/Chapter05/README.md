# Chapter 5: Making a 2D game

## Installing

```sh
npm install
```

## Running

```sh
npm start
```
