# Chapter 10: Building a Digital Wallet for Desktops

## Installing

```sh
npm install
```

## Running

```sh
# terminal 1: run local web server
npm start

# terminal 2: run electron app
npm run electron
```
