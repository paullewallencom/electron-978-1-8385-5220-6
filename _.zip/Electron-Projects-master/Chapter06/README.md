# Chapter 6: Building a music player

## Installing

```sh
npm install
```

## Running

```sh
npm start
```
