# Chapter 8: Build a group chat application with Firebase

## Installing

```sh
npm install
```

## Running

```sh
# terminal 1: run local web server
npm run serve

# terminal 2: run electron app
npm start
```
