# Chapter 7: Analytics, Bug Tracking and Licensing

## Installing

```sh
npm install
```

## Running

```sh
npm start
```
