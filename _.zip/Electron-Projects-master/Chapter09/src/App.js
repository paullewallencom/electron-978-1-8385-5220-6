import React from 'react';
import './App.css';
import Editor from './Editor';

function App() {
  return (
    <div className="App">
      <Editor></Editor>
    </div>
  );
}

export default App;
