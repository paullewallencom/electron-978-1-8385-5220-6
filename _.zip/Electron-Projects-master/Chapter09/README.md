# Chapter 9: Building an eBook Editor and Generator

## Installing

```sh
npm install
```

## Running

```sh
# terminal 1: run local web server
npm start

# terminal 2: run electron app
npm run electron
```
