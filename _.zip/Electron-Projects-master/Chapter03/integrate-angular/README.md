# Chapter 3: Integrating Electron applications with Angular, React, and Vue / Angular

## Installing

```sh
npm install
```

## Running

```sh
# terminal 1: run local web server
npm run serve

# terminal 2: run electron app
npm start
```
